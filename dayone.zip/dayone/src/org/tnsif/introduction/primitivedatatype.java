//primirive datatype program 
package org.tnsif.introduction;

public class primitivedatatype {

	public static void main(String[] args) {
		byte num1=-125;
		//byte =-128 to 127
		System.out.println(num1);
		short  num2 =3467;
		//short -32768 to 32767
		System.out.println(num2);
		//int 
		long num3 =38477443l;
		System.out.println(num3);
		
		char s = 'g';
		System.out.println("charater  "+s);
		
	}

}
