//program on charter 
package org.tnsif.introduction;

public class charname {

	public static void main(String[] args) {
		char ch ='s';
		System.out.println(ch);
		char ch2 =65;
		System.out.println(ch2);

	}

}
