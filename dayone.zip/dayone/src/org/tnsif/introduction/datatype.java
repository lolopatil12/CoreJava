//program on demonstrate datatype
package org.tnsif.introduction;

public class datatype {

	public static void main(String[] args) {
		int x=5;
		//interger whole number
		System.out.println("the number is "+x);
		float num =103/45;
		//float and double  value up to decimal
		// '/' questient '%' remider 
		System.out.println("the number is "+num);
		double num2 =10d/3d;
		//give value upto 16 percision
		System.out.println("the number is "+num2);
		
		float num3 =10f/3f;
		//upto 7 percision 
		System.out.println("the number is "+num3);

		
			}

}
