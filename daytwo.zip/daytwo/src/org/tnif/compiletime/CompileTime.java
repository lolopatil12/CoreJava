//program compile time
package org.tnif.compiletime;

public class CompileTime {

	public static void main(String[] args) {
		float salary = 56789.98f;
		System.out.print("salary is :"+salary);
		

	}

}
