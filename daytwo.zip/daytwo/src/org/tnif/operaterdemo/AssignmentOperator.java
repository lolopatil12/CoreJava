//program on assignment operator
package org.tnif.operaterdemo;

public class AssignmentOperator {

	public static void main(String[] args) {
		int x=21 ,y=3;
	x=y;
	System.out.println(x);

	}

}
