//program on demonstrate  bitwise operator 
package org.tnif.operaterdemo;

public class BitwiseOperator {

	public static void main(String[] args) {
		int result1 =10&7;
		int result2 =10|7;
		int result3 =10^7;
		int result4 =8>>1;
		int result5 =8<<2;
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);
		System.out.println(result4);
		System.out.println(result5);
		
		

	}

}
