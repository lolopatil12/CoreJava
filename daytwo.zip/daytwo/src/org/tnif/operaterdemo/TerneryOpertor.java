//ternary operator
package org.tnif.operaterdemo;

public class TerneryOpertor {

	public static void main(String[] args) {
		/*syntax
		 * (condition)?"True":"False";
		 */
		
		String isEven=(5%2==0)?"Even":"Odd";
		System.out.println(isEven);
	}

}
