//program on retional operator
package org.tnif.operaterdemo;

public class RentionalOperator {

	public static void main(String[] args) {
		int weight1 =45,weight2=37;
		boolean  result=(weight1==weight2);
		System.out.println(result);

	}

}
