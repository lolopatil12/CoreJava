//Enhanced for loop program 
package org.tnisf.looping;

public class EnhancedForLoop {

	public static void main(String[] args) {
		char array1[]= {'A','B','C'};
		for(int itr:array1)
		{
			System.out.println(itr+"");
		}

}
}
