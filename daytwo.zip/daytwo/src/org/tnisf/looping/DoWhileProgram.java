//program demonstate on do while loop
package org.tnisf.looping;

public class DoWhileProgram {

	public static void main(String[] args) {
		int a =12;
		do 
		{
			System.out.println("value of a is "+a);
		}while(a<11);

	}

}
