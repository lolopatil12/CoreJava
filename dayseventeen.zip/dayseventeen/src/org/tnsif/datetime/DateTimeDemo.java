package org.tnsif.datetime;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;

public class DateTimeDemo {

	public static void main(String[] args) {
		LocalDate obj1 = LocalDate.of(2002, 02, 04);
		System.out.println(obj1);		
		LocalDateTime dt = LocalDateTime.now();
		System.out.println(dt);
		LocalDate d = LocalDate.now();
		System.out.println(d);
		ZonedDateTime zd = ZonedDateTime.now();
		System.out.println(zd);
		OffsetTime o = OffsetTime.now();
		System.out.println(o);
		OffsetDateTime os = OffsetDateTime.now();
		System.out.println(os);
		

	}

}
