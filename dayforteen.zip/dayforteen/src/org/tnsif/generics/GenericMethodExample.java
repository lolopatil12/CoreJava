package org.tnsif.generics;

public class GenericMethodExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
