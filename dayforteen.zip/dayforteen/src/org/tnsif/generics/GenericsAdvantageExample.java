package org.tnsif.generics;

import java.util.List;
import java.util.ArrayList;


public class GenericsAdvantageExample {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList();
		list.add(11);
		list.add(23);
		System.out.println(list);
		
		ArrayList arr1 = new ArrayList();
		arr1.add("St.John");
		System.out.println(arr1);
		String str = (String)arr1.get(0);
		System.out.println(str);

	}

}
