//Multithreding program.
package org.tnsif.multithreding;
public class ThreadExample {

	public static void main(String[] args) {
		//Returns a reference to the currently executing thread object.
		Thread t=Thread.currentThread();
		System.out.println("current thread :- "+t);

	}

}