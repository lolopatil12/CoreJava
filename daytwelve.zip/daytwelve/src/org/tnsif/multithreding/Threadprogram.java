//creating a thread using thread class
package org.tnsif.multithreding;
public class Threadprogram extends Thread {
	public  void run()
	{
		System.out.print("Thread is in running state");
	}

	public static void main(String[] args) {
		//Threadprogram.run();
		Threadprogram t=new Threadprogram();
		t.start();
		//if thread is in starting and running state we can not start again
		//t.start();
		
		

	}

}
