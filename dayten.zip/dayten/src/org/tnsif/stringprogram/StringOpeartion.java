package org.tnsif.stringprogram;

public class StringOpeartion {

	public static void main(String[] args) {
		String str1=new String("Bhoomi ");
		System.out.println(str1.toUpperCase());
		System.out.println(str1.length());
		System.out.println(str1.lastIndexOf('u'));
		System.out.println(str1.hashCode());
	}

}
