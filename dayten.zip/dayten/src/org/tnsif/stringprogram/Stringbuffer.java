package org.tnsif.stringprogram;

public class Stringbuffer {

	public static void main(String[] args) {
		StringBuffer str1 =new StringBuffer(" valay");
		//by default capcity of empty string is 16
		System.out.println(str1.capacity());
		System.out.println(str1.charAt(2));

	}

}
