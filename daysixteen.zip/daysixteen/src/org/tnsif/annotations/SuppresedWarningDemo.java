package org.tnsif.annotations;
import java.util.Set;
import java.util.TreeSet;
public class SuppresedWarningDemo {
	    @SuppresedWarnings("unchecked")
	public static void main(String[] args) {
	    	@SuppresedWarnings("rawtypes")
			Set<E> s = new TreeSet();
			s.add(12);
			s.add(5);
	}

}
