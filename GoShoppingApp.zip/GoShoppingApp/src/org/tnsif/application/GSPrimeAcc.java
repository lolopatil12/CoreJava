package org.tnsif.application;
import org.tnsif.framework.PrimeAcc;

public class GSPrimeAcc {
	public GSPrimeAcc(int accNo, String accNm, float charges, boolean isPrime) 
	{
		super();
	}

	@Override
	public String toString() {
		return "GSPrimeAcc [toString()=" + super.toString() + "]";
	}


}
