package org.tnsif.multilevelinheritance;

public class MultilevelDemo {

	public static void main(String[] args) {
		City c =new City();
		c.setCityname("pune");
		c.setArea("viman nagar");
		c.setStatename("maharastra");
		c.setLanguage("marathi");
		c.setCityname("india");
		c.setStatename("dehali");
		c.setCountryname("asd");
		c.setCountrycaptial("nagapur");
		
		System.out.println(c);
		
		

	}

}
