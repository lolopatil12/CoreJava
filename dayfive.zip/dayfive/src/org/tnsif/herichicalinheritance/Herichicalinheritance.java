package org.tnsif.herichicalinheritance;

public class Herichicalinheritance {

	public static void main(String[] args) {
		SnowCone s=new SnowCone(12,"Sumsung21");
		Trramisu t =new Trramisu (13,"Relame 10 pro plus");
		System.out.println(s);
		System.out.println(t);
	}

}
