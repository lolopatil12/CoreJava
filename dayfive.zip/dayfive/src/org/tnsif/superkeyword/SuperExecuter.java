package org.tnsif.superkeyword;

public class SuperExecuter {

	public static void main(String[] args) {
		Tiger t =new Tiger();
		t.display();

	}

}
