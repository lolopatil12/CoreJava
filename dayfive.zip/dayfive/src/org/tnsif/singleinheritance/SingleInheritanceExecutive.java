package org.tnsif.singleinheritance;

public class SingleInheritanceExecutive {

	public static void main(String[] args) {
		Student s =new Student("sandhya","234455666","mumbai",234455566L,"sjcem",34);
		System.out.println(s);
		

	}

}
