package org.tnsif.enumration;

public class enumartionexecuter {

	public static void main(String[] args) {
		Size.SMALL.displaysize();

	}

}