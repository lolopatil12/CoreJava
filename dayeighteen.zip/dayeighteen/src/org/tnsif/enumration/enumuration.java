package org.tnsif.enumration;

public class enumuration {

	public static void main(String[] args) {
		ticketcategory t=ticketcategory .AC;
		System.out.println(t);

	}

}
