package org.tnsif.enumration;
public interface pizza {
	//by default its abstract method
	void displaysize();

}