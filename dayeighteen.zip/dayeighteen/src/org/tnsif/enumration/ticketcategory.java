package org.tnsif.enumration;

public enum ticketcategory {
	AC,SLEEPER,GENERAL

}
