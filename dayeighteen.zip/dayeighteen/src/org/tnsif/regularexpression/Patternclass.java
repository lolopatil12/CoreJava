package org.tnsif.regularexpression;
import java.util.Scanner;

public class Patternclass {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter a string :");
		String input =sc.next() ;
		String pattern ="Hey there  is regular expression ";
		boolean result =pattern.matches(pattern);
		System.out.println(result);


	}

}
