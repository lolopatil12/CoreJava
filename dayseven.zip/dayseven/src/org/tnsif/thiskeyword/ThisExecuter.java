package org.tnsif.thiskeyword;

public class ThisExecuter {
	public static void main(String[] args) {
		ThisKeywordEx t1 = new ThisKeywordEx(126,521464L);
		t1.print();

}
}