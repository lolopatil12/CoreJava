package org.tnsif.exceptiondemo;

public class ArithmeticExampleException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
