package org.tnsif.exceptiondemo;

public class FinallyBlockExample {

	public static void main(String[] args) {
		int arr[] = new int[] {101,33,78};
		
		
		System.out.println("Array is: ");
		try {
			System.out.println(arr[3]);
			System.exit(0);
		}
		catch(Exception e){
			System.out.println("Exception handled"+e);
			
		}
		finally {
			/*2. when finally clock contains */
			System.out.println(13/0);
			System.out.println("Finally block");
		}
	}

}
