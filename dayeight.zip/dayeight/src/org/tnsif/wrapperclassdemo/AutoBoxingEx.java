//autoboxing program
/*
 * *auto boxing :- conversion  of primitive to object type 
 * example :- char to character
 * unboxing oppsite to autoboxing 
 */
package org.tnsif.wrapperclassdemo;

public class AutoBoxingEx {

	public static void main(String[] args) {
int num =1045;
		
		//object type 
		//autoboxing
		//convert primitive to object type
		Integer x =num;
		System.out.println("value of x is "+x);
		

	}

}
