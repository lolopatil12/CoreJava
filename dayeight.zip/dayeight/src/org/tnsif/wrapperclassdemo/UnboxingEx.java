//unboxing program
/*
 * *unboxing :- conversion  of  object to primitive type 
 * example :-  character to char 
 * unboxing oppsite to autoboxing 
 */
package org.tnsif.wrapperclassdemo;

public class UnboxingEx {

	public static void main(String[] args) {
		Character c = 'A';
		char ch =c;
		System.out.println(ch);
	}

}
