package org.tnsif.interfacedemo;

public interface Outerinterface {
	int sum ();
	interface innerinterface {
		String Concanate();
	}


}
