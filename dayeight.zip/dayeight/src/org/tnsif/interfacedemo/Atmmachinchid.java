package org.tnsif.interfacedemo;

public class Atmmachinchid implements ATMmachine {
	public void withdraw() {
		String amountwith;
		System.out.println("Withdraw amount :-"+amountwith);
		
	}

	public void deposit() {
		String amountdepo;
		System.out.println("deposite amount  :-"+amountdepo);
		
	}
	
}
