package org.tnsif.interfacedemo;
//Exactly one abstract method
//Functional interface :- an interface which contain exactly one method

//Below annotation tells us that interface as one abstract method
@FunctionalInterface
public interface Receipe {
	//by default all the method inside an interface are public abstact and variable are public static final 
		//abstract method 
		
		String displayname();
		//String print();
		
}
