package org.tnsif.constructoroverloading;

public class ConstructorOverloadingExecutor {

	public static void main(String[] args) {
		
	}

}
