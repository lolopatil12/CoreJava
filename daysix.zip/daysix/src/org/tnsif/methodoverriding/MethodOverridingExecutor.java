package org.tnsif.methodoverriding;

public class MethodOverridingExecutor {

	public static void main(String[] args) {
		 HDFS h1 =new HDFS();
		 System.out.println( h1.getInterestRate());

	}

}
